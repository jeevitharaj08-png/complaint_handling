# Test Traceability Matrix — Complaint Handling System (Optimised Suite)

This document maps all **29 application functions** to their corresponding automated unit test cases within the optimised Google Test suite (**67 test cases**). Every function is directly exercised by dedicated tests covering normal execution, boundaries, edge cases, error paths, and loop iterations.

All 67 test cases execute within isolated sandboxes, leaving production data completely unmodified.

---

## Test Traceability Matrix (67 Tests)

| Function | Test ID | GTest Suite & Name | Scenario & Preconditions | Expected Result | Status |
|---|---|---|---|---|:---:|
| `getTimestamp` (F1) | `TC_VAL_01` | `ValidationTest.GetTimestamp_ValidFormatting` | Valid buffer `char[64]` | Formats datetime string `YYYY-MM-DD HH:MM:SS` (len 19) | **PASS** |
| `getTimestamp` (F1) | `TC_VAL_02` | `ValidationTest.GetTimestamp_NullBuffer_DoesNotCrash` | `buffer = NULL`, `size = 64` | Returns immediately without segmentation fault | **PASS** |
| `getTimestamp` (F1) | `TC_VAL_03` | `ValidationTest.GetTimestamp_ZeroOrSmallSize_HandlesSafely` | `size = 0` and small buffer `size = 5` bytes | Zero size unmodified; small size safe without buffer overflow | **PASS** |
| `getTimestamp` (F1) | `TC_VAL_04` | `ValidationTest.GetTimestamp_LocaltimeFailure_SetsNA` | `g_fail_localtime = 1` mock | Populates destination buffer with `"N/A"` | **PASS** |
| `readString` (F2) | `TC_VAL_05` | `ValidationTest.ReadString_NormalInput_StripsNewline` | Input `"Hello World\n"`, prompt provided | Strips `\n`, prints prompt, buffer has `"Hello World"` | **PASS** |
| `readString` (F2) | `TC_VAL_06` | `ValidationTest.ReadString_WindowsCRLF_StripsBothCharacters` | Input `"Windows Line\r\n"` | Strips both `\r` and `\n` | **PASS** |
| `readString` (F2) | `TC_VAL_07` | `ValidationTest.ReadString_PipeCharacterReplacement` | Input `"user\|data\|injection\|attempt\n"` | Replaces `\|` with `-` (`"user-data-injection-attempt"`) | **PASS** |
| `readString` (F2) | `TC_VAL_08` | `ValidationTest.ReadString_PromptsAndBufferBoundaries` | Null/empty prompt, null buffer, zero size | Reads input without prompt; null/zero guards return safely | **PASS** |
| `readString` (F2) | `TC_VAL_09` | `ValidationTest.ReadString_EOFAndEmptyLine` | Simulated EOF on stdin and empty line `"\n"` | Returns empty string `""` safely | **PASS** |
| `readInt` (F3) | `TC_VAL_10` | `ValidationTest.ReadInt_ValidAndBoundaries` | In-range value (3), minVal (1), maxVal (10) | Returns parsed integers 3, 1, 10 | **PASS** |
| `readInt` (F3) | `TC_VAL_11` | `ValidationTest.ReadInt_InvalidInputsReprompt` | Below range, above range, non-numeric, trailing alpha, empty | Rejects invalid inputs, reprompts, accepts valid input (4) | **PASS** |
| `readInt` (F3) | `TC_VAL_12` | `ValidationTest.ReadInt_ImmediateEOF_ReturnsMinVal` | Simulated stdin EOF | Returns `minVal` safely without infinite loop | **PASS** |
| `findCustomerByUsername` (F4) | `TC_CUST_01` | `CustomerTest.FindCustomerByUsername_NullOrEmpty` | `username = NULL` and `username = ""` | Returns `NULL` defensively | **PASS** |
| `findCustomerByUsername` (F4) | `TC_CUST_02` | `CustomerTest.FindCustomerByUsername_EmptyList` | `customerHead = NULL` | Returns `NULL` safely | **PASS** |
| `findCustomerByUsername` (F4) | `TC_CUST_03` | `CustomerTest.FindCustomerByUsername_MultiNodeListTraversal` | 3 customer accounts in linked list | Matches head, middle, tail, returns NULL on missing | **PASS** |
| `findComplaintById` (F5) | `TC_CMP_01` | `ComplaintsTest.FindComplaintById_NullOrEmpty` | `complaintId = NULL` and `complaintId = ""` | Returns `NULL` defensively | **PASS** |
| `findComplaintById` (F5) | `TC_CMP_02` | `ComplaintsTest.FindComplaintById_EmptyList` | `complaintHead = NULL` | Returns `NULL` safely | **PASS** |
| `findComplaintById` (F5) | `TC_CMP_03` | `ComplaintsTest.FindComplaintById_MultiNodeListTraversal` | 3 complaints in linked list | Matches head (`CMP101`), mid (`CMP102`), tail (`CMP103`), NULL on missing | **PASS** |
| `addAuditEntry` (F6) | `TC_CMP_04` | `ComplaintsTest.AddAuditEntry_NullSafetyAndFallbacks` | `node = NULL` and NULL action/by/details | NULL node returns safely; NULL params fallback to defaults | **PASS** |
| `addAuditEntry` (F6) | `TC_CMP_05` | `ComplaintsTest.AddAuditEntry_MultiNodeAppends` | Valid `ComplaintNode`, multiple events | Appends to empty head, then traverses `next` to tail | **PASS** |
| `addAuditEntry` (F6) | `TC_CMP_06` | `ComplaintsTest.AddAuditEntry_MemoryAllocationFailure` | `g_fail_malloc = 1` mock | Prints allocation error message, `auditHead` remains unchanged | **PASS** |
| `autoAssignAgent` (F7) | `TC_CMP_07` | `ComplaintsTest.AutoAssignAgent_EqualWorkloadAndAllInactive` | 0 complaints and all 10 agents inactive | Workload 0 selects agent 0; all inactive returns -1 | **PASS** |
| `autoAssignAgent` (F7) | `TC_CMP_08` | `ComplaintsTest.AutoAssignAgent_SelectsLeastOpenWorkload` | Agent 1 has 2 tickets, Agent 2 has 1 ticket, resolved present | Selects Agent 2 (index 1); resolved/closed tickets excluded | **PASS** |
| `initSystem` (F8) | `TC_STOR_01` | `StorageTest.InitSystem_ColdStartAndPaddedDefaults` | Sandbox with no files in `data/`, and partial agents file | Provisions 10 default agents; pads partial agents to 10 | **PASS** |
| `initSystem` (F8) | `TC_STOR_02` | `StorageTest.InitSystem_CorruptCountersAndNormalEntityLoading` | Corrupt counters, valid customers/complaints/audits | Clamps counters to 101/1001; restores all linked entities | **PASS** |
| `initSystem` (F8) | `TC_STOR_03` | `StorageTest.InitSystem_MalformedDataAndDefensiveFailures` | Malformed lines in 4 files, malloc failure mocks | Safely skips corrupt lines; handles system malloc failures | **PASS** |
| `saveAllData` (F9) | `TC_STOR_04` | `StorageTest.SaveAllData_NormalAndFopenFailures` | Empty timestamps/notes, `g_fail_fopen = 1` mock | Persists records with fallback strings; handles fopen failure | **PASS** |
| `freeAllMemory` (F10) | `TC_STOR_05` | `StorageTest.FreeAllMemory_EmptyAndPopulated` | Empty lists and populated customers/complaints/audits | Frees all nodes, resets heads to NULL safely | **PASS** |
| `customerMenu` (F11) | `TC_CUST_04` | `CustomerTest.CustomerMenu_ReturnDirectly` | Choice `3` (Return to main menu) | Returns cleanly to caller | **PASS** |
| `customerMenu` (F11) | `TC_CUST_05` | `CustomerTest.CustomerMenu_NavigateRegisterAndLoginThenReturn` | Choice 1 (abort register) and Choice 2 (fail login) then 3 | Launches registration/login workflows then returns | **PASS** |
| `customerRegister` (F12) | `TC_CUST_06` | `CustomerTest.CustomerRegister_MandatoryFieldValidation` | Blank full name, username, password, contact inputs | Aborts registration with corresponding error messages | **PASS** |
| `customerRegister` (F12) | `TC_CUST_07` | `CustomerTest.CustomerRegister_DuplicateUsernameAborts` | Username already taken in database | Aborts with `"already taken"` message | **PASS** |
| `customerRegister` (F12) | `TC_CUST_08` | `CustomerTest.CustomerRegister_SuccessfulRegistrationAndListAppends` | Registering 3 consecutive accounts | Creates head, appends 2nd, traverses list to append 3rd | **PASS** |
| `customerRegister` (F12) | `TC_CUST_09` | `CustomerTest.CustomerRegister_MemoryAllocationFailure` | `g_fail_malloc = 1` mock | Handles malloc failure safely with error message | **PASS** |
| `customerLogin` (F13) | `TC_AUTH_01` | `AuthenticationTest.CustomerLogin_Successful` | Valid credentials, then dashboard logout | Authenticates, enters dashboard, logs out cleanly | **PASS** |
| `customerLogin` (F13) | `TC_AUTH_02` | `AuthenticationTest.CustomerLogin_InvalidCredentials` | Non-existent user, and valid user with wrong password | Rejects invalid logins with authentication failure message | **PASS** |
| `customerDashboard` (F14) | `TC_CUST_10` | `CustomerTest.CustomerDashboard_DispatchSubFunctionsAndLogout` | Options 1 (register), 2 (view), 3 (track), 4 (history), 5 (logout) | Dispatches all customer workflows and exits cleanly | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_09` | `ComplaintsTest.CustomerRegisterComplaint_EmptyDescriptionAndMallocFailure` | Empty description, `g_fail_malloc = 1` mock | Aborts on empty description; handles allocation failure | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_10` | `ComplaintsTest.CustomerRegisterComplaint_ActiveAssignmentAndListGrowth` | Lodging complaint with active agent, collision trigger, appends | Assigns active agent, advances collision loop, appends to tail | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_11` | `ComplaintsTest.CustomerRegisterComplaint_InactiveAgentsFallback` | Lodging complaint when all 10 agents are inactive | Creates ticket with status PENDING, agent UNASSIGNED | **PASS** |
| `customerViewComplaints` (F16) | `TC_CUST_11` | `CustomerTest.CustomerViewComplaints_ZeroAndMultiple` | Zero complaints account, and multiple complaints account | Displays zero message; displays user tickets with isolation | **PASS** |
| `customerTrackComplaint` (F17) | `TC_CUST_12` | `CustomerTest.CustomerTrackComplaint_NotFoundAndSecurityViolation` | Missing ID, and attempting to view another customer's ticket | Shows not found error; rejects unauthorized access | **PASS** |
| `customerTrackComplaint` (F17) | `TC_CUST_13` | `CustomerTest.CustomerTrackComplaint_AllStagesProgression` | Complaints in all 7 status states | Displays Stages 1, 2, 3, 3.5, 4, 5, and custom state | **PASS** |
| `customerViewHistory` (F18) | `TC_CUST_14` | `CustomerTest.CustomerViewHistory_ValidationAndAuditRecords` | Missing ID, wrong customer ticket, zero audits, multiple audits | Enforces security; displays all formatted audit events | **PASS** |
| `agentMenu` (F19) | `TC_AUTH_03` | `AuthenticationTest.AgentMenu_ReturnDirectly` | Choice `2` (Return to main menu) | Returns cleanly to caller | **PASS** |
| `agentMenu` (F19) | `TC_AUTH_04` | `AuthenticationTest.AgentMenu_CredentialValidationAndInactiveCheck` | Wrong password, and inactive agent account login | Rejects bad password; denies access to inactive agent | **PASS** |
| `agentMenu` (F19) | `TC_AUTH_05` | `AuthenticationTest.AgentMenu_SuccessfulLoginAndLogout` | Valid agent credentials, dashboard logout (4), return (2) | Enters agent dashboard, logs out cleanly | **PASS** |
| `agentDashboard` (F20) | `TC_AGT_01` | `AgentTest.AgentDashboard_WorkloadCalculation` | Assigned, resolved, closed tickets across agents | Calculates active workload excluding closed/resolved | **PASS** |
| `agentDashboard` (F20) | `TC_AGT_02` | `AgentTest.AgentDashboard_SubmenuDispatchAndLogout` | Options 1 (view), 2 (update abort), 3 (audit view), 4 (logout) | Dispatches all agent submenus and exits cleanly | **PASS** |
| `agentViewAssigned` (F21) | `TC_AGT_03` | `AgentTest.AgentViewAssigned_ZeroComplaints` | Agent with zero assigned complaints | Prints no complaints assigned message | **PASS** |
| `agentViewAssigned` (F21) | `TC_AGT_04` | `AgentTest.AgentViewAssigned_MultipleComplaintsWithIsolation` | Multiple complaints across different agents | Displays assigned complaints; isolates other agents' tickets | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_05` | `AgentTest.AgentUpdateComplaint_NotFoundAndNotAssigned` | Non-existent ID, and ticket assigned to another agent | Rejects update with appropriate error message | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_06` | `AgentTest.AgentUpdateComplaint_CancelAction` | Choice `4` (Cancel action) | Cancels update without modifying state | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_07` | `AgentTest.AgentUpdateComplaint_StatusTransitionsAndResolvedCounters` | Status 1 (IN_PROGRESS default note), 2 (RESOLVED), 3 (ESCALATED) | Updates statuses, increments resolved count, sets timestamps | **PASS** |
| `managerMenu` (F23) | `TC_AUTH_06` | `AuthenticationTest.ManagerMenu_ReturnDirectly` | Choice `2` (Return to main menu) | Returns cleanly to caller | **PASS** |
| `managerMenu` (F23) | `TC_AUTH_07` | `AuthenticationTest.ManagerMenu_CredentialValidation` | Non-existent manager user, and correct user with wrong pass | Rejects invalid logins with failure message | **PASS** |
| `managerMenu` (F23) | `TC_AUTH_08` | `AuthenticationTest.ManagerMenu_SuccessfulLoginAndLogout` | Valid manager credentials, dashboard logout (6), return (2) | Enters manager dashboard, logs out cleanly | **PASS** |
| `managerDashboard` (F24) | `TC_MGR_01` | `ManagerTest.ManagerDashboard_LogoutDirectly` | Choice `6` (Logout) | Exits dashboard immediately | **PASS** |
| `managerDashboard` (F24) | `TC_MGR_02` | `ManagerTest.ManagerDashboard_SubmenuDispatchAndAuditLogs` | Options 1, 2, 3, 4, 5 (empty & populated audits), 6 (logout) | Dispatches all manager tools and displays system audit trail | **PASS** |
| `managerViewAllComplaints` (F25) | `TC_MGR_03` | `ManagerTest.ManagerViewAllComplaints_ZeroComplaints` | System with zero complaints | Displays zero complaints summary table | **PASS** |
| `managerViewAllComplaints` (F26) | `TC_MGR_04` | `ManagerTest.ManagerViewAllComplaints_AllStatusesCovered` | Complaints in all 6 standard statuses + custom status | Correctly tabulates count for each status | **PASS** |
| `managerAssignComplaint` (F26) | `TC_MGR_05` | `ManagerTest.ManagerAssignComplaint_NotFoundAndInactiveValidation` | Missing complaint ID, non-existent agent, inactive agent | Validates all lookup failures and aborts reassignment | **PASS** |
| `managerAssignComplaint` (F26) | `TC_MGR_06` | `ManagerTest.ManagerAssignComplaint_SuccessPendingAndReassignment` | PENDING ticket, and reassignment of ASSIGNED ticket | Promotes PENDING to ASSIGNED; reassigns agent | **PASS** |
| `managerUpdateComplaint` (F27) | `TC_MGR_07` | `ManagerTest.ManagerUpdateComplaint_NotFoundCancelAndStatusTransitions` | Missing ID, cancel (5), transitions to IN_PROGRESS, RESOLVED, CLOSED, ESCALATED | Validates transitions, sets timestamps, records audit entries | **PASS** |
| `managerAgentManagement` (F28) | `TC_MGR_08` | `ManagerTest.ManagerAgentManagement_ReturnNotFoundAndToggle` | Return (2), invalid agent ID, toggle ACTIVE -> INACTIVE -> ACTIVE | Toggles agent active status with workload tally | **PASS** |
| `main` (F29) | `TC_MAIN_01` | `MainFunctionTest.Main_ImmediateExit` | Choice `4` (Exit) | Displays welcome, saves state, exits with return code 0 | **PASS** |
| `main` (F29) | `TC_MAIN_02` | `MainFunctionTest.Main_FullMenuNavigationCycle` | Choices 1 -> 3, 2 -> 2, 3 -> 2, 4 | Navigates all 3 portals and exits cleanly | **PASS** |

---

## Test Distribution Summary

| Test File | Target Functions | Optimised Test Count | Original Test Count | Redundancy Eliminated |
|:---|:---|:---:|:---:|:---:|
| `test_validation.cpp` | `getTimestamp`, `readString`, `readInt` (F1–F3) | **12** | 21 | -9 |
| `test_authentication.cpp` | `customerLogin`, `agentMenu`, `managerMenu` (F13, F19, F23) | **8** | 11 | -3 |
| `test_customer.cpp` | `findCustomerByUsername`, `customerMenu`, `customerRegister`, `customerDashboard`, `customerViewComplaints`, `customerTrackComplaint`, `customerViewHistory` (F4, F11, F12, F14, F16, F17, F18) | **14** | 24 | -10 |
| `test_complaints.cpp` | `findComplaintById`, `addAuditEntry`, `autoAssignAgent`, `customerRegisterComplaint` (F5, F6, F7, F15) | **11** | 16 | -5 |
| `test_agent.cpp` | `agentDashboard`, `agentViewAssigned`, `agentUpdateComplaint` (F20–F22) | **7** | 13 | -6 |
| `test_manager.cpp` | `managerDashboard`, `managerViewAllComplaints`, `managerAssignComplaint`, `managerUpdateComplaint`, `managerAgentManagement` (F24–F28) | **8** | 15 | -7 |
| `test_storage.cpp` | `initSystem`, `saveAllData`, `freeAllMemory` (F8–F10) | **5** | 10 | -5 |
| `test_main.cpp` | `main` (as `app_main`) (F29) | **2** | 4 | -2 |
| **TOTAL** | **All 29 Functions** | **67** | **114** | **-47 (-41.2%)** |
