#ifndef TEST_HELPERS_H
#define TEST_HELPERS_H

#include <gtest/gtest.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Map main to app_main while including complaint_system.h to avoid conflict with GTest main */
#define main app_main
#include "complaint_system.h"
#undef main

/* Test Seam Mock Hooks for GNU ld --wrap */
extern int g_fail_malloc;
extern int g_fail_malloc_audit_only;
extern int g_fail_localtime;
extern int g_fail_fopen;

#ifdef __cplusplus
}
#endif

/**
 * @brief RAII Sandbox for isolating tests from production data.
 *
 * Creates a unique isolated temporary directory, switches working directory into it,
 * creates data/ folder, and cleans up everything on destruction.
 */
class ScopedSandbox {
public:
    char sandboxDir[256];
    char originalDir[512];

    ScopedSandbox() {
        if (!getcwd(originalDir, sizeof(originalDir))) {
            strcpy(originalDir, ".");
        }

        char templatePath[] = "/tmp/cchhss_test_XXXXXX";
        char *created = mkdtemp(templatePath);
        if (created) {
            strncpy(sandboxDir, created, sizeof(sandboxDir) - 1);
            sandboxDir[sizeof(sandboxDir) - 1] = '\0';
            if (chdir(sandboxDir) == 0) {
                mkdir("data", 0755);
            }
        } else {
            sandboxDir[0] = '\0';
        }
    }

    ~ScopedSandbox() {
        freeAllMemory();
        if (originalDir[0] != '\0') {
            chdir(originalDir);
        }
        if (sandboxDir[0] != '\0') {
            std::string cmd = "rm -rf " + std::string(sandboxDir);
            (void)system(cmd.c_str());
        }
    }

    void writeFile(const std::string& relativePath, const std::string& content) {
        std::ofstream ofs(relativePath.c_str(), std::ios::binary);
        ofs << content;
        ofs.close();
    }

    std::string readFile(const std::string& relativePath) {
        std::ifstream ifs(relativePath.c_str(), std::ios::binary);
        if (!ifs.is_open()) return "";
        std::stringstream ss;
        ss << ifs.rdbuf();
        return ss.str();
    }
};

/**
 * @brief RAII helper to feed stdin and capture stdout.
 */
class StdioCapture {
private:
    int savedStdin;
    int savedStdout;
    FILE *stdinTemp;
    FILE *stdoutTemp;
    bool active;

public:
    StdioCapture(const std::string& simulatedInput = "") : active(false) {
        fflush(stdout);
        fflush(stdin);
        clearerr(stdin);

        savedStdin = dup(STDIN_FILENO);
        savedStdout = dup(STDOUT_FILENO);

        stdinTemp = tmpfile();
        if (stdinTemp) {
            if (!simulatedInput.empty()) {
                fwrite(simulatedInput.data(), 1, simulatedInput.size(), stdinTemp);
                fflush(stdinTemp);
                rewind(stdinTemp);
            }
            dup2(fileno(stdinTemp), STDIN_FILENO);
            clearerr(stdin);
            fseek(stdin, 0, SEEK_SET);
        }

        stdoutTemp = tmpfile();
        if (stdoutTemp) {
            dup2(fileno(stdoutTemp), STDOUT_FILENO);
        }

        active = true;
    }

    std::string getOutput() {
        fflush(stdout);
        if (!stdoutTemp) return "";
        rewind(stdoutTemp);
        std::string out;
        char buffer[1024];
        while (size_t bytes = fread(buffer, 1, sizeof(buffer), stdoutTemp)) {
            out.append(buffer, bytes);
        }
        return out;
    }

    void restore() {
        if (!active) return;
        fflush(stdout);
        fflush(stdin);
        clearerr(stdin);

        dup2(savedStdin, STDIN_FILENO);
        close(savedStdin);
        clearerr(stdin);
        fseek(stdin, 0, SEEK_CUR);

        dup2(savedStdout, STDOUT_FILENO);
        close(savedStdout);

        if (stdinTemp) {
            fclose(stdinTemp);
            stdinTemp = NULL;
        }
        if (stdoutTemp) {
            fclose(stdoutTemp);
            stdoutTemp = NULL;
        }
        active = false;
    }

    ~StdioCapture() {
        restore();
    }
};

/**
 * @brief RAII Fail-Malloc Guard for testing memory allocation error paths.
 */
class FailMallocGuard {
public:
    FailMallocGuard() { g_fail_malloc = 1; }
    ~FailMallocGuard() { g_fail_malloc = 0; }
};

/**
 * @brief RAII Fail-Localtime Guard for testing localtime failure path.
 */
class FailLocaltimeGuard {
public:
    FailLocaltimeGuard() { g_fail_localtime = 1; }
    ~FailLocaltimeGuard() { g_fail_localtime = 0; }
};

/**
 * @brief RAII Fail-Fopen Guard for testing file opening failure paths.
 */
class FailFopenGuard {
public:
    FailFopenGuard() { g_fail_fopen = 1; }
    ~FailFopenGuard() { g_fail_fopen = 0; }
};

#endif /* TEST_HELPERS_H */
